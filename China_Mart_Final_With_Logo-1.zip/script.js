const products=[
{name:"5-in-1 Gas Stove Lighter",price:899,old:1199,img:"products/gas-stove-lighter.jpg",badge:"HOT"},
{name:"Ziba Multipurpose Container",price:1499,old:1899,img:"products/ziba-multipurpose-container.jpg",badge:"NEW"},
{name:"Drawer Jewelry & Makeup Organizer",price:1999,old:2499,img:"products/jewelry-box.jpg",badge:"BEST"},
{name:"Nice Portable Water Bottle",price:799,old:999,img:"products/nice-bottle.jpg",badge:""},
{name:"Premium Beauty Organizer Set",price:1799,old:2299,img:"products/beauty-organizer.jpg",badge:""},
{name:"4-Tier Rolling Storage Rack",price:3499,old:4299,img:"products/rolling-storage-rack.jpg",badge:"SALE"},
{name:"Bathroom Wall Storage Shelf",price:1599,old:1999,img:"products/bathroom-shelf.jpg",badge:""},
{name:"Electric Scalp Massager",price:1299,old:1699,img:"products/electric-scalp-massager.jpg",badge:"HOT"},
{name:"Mini Bag Sealing Machine",price:899,old:1199,img:"products/mini-sealing-machine.jpg",badge:"NEW"},
{name:"3-Layer Home Organizer",price:2299,old:2799,img:"products/home-organizer.jpg",badge:"BEST"}
];

const grid=document.getElementById("productGrid");
let cart=0;
function money(n){return "Rs. "+n.toLocaleString("en-PK")}
function render(list=products){
 grid.innerHTML=list.map((p,i)=>`
 <article class="product">
 ${p.badge?`<span class="badge">${p.badge}</span>`:""}
 <div class="product-img" style="background-image:url('${p.img}')"></div>
 <div class="product-info">
   <h3>${p.name}</h3>
   <div class="price">${money(p.price)} <span class="old">${money(p.old)}</span></div>
   <button class="add" onclick="addToCart()">ADD TO CART</button>
 </div>
 </article>`).join("");
}
function addToCart(){
 cart++;document.getElementById("cartCount").textContent=cart;
 const t=document.getElementById("toast");t.classList.add("show");
 setTimeout(()=>t.classList.remove("show"),1600);
}
render();

const drawer=document.getElementById("drawer"),overlay=document.getElementById("overlay");
document.getElementById("menuBtn").onclick=()=>{drawer.classList.add("open");overlay.style.display="block"};
document.getElementById("closeDrawer").onclick=()=>{drawer.classList.remove("open");overlay.style.display="none"};
overlay.onclick=()=>{drawer.classList.remove("open");overlay.style.display="none"};

const modal=document.getElementById("searchModal");
function openSearch(){modal.classList.add("active");overlay.style.display="block";document.getElementById("searchInput").focus()}
document.getElementById("searchBtn").onclick=openSearch;
document.getElementById("searchBtn2").onclick=openSearch;
document.getElementById("closeSearch").onclick=()=>{modal.classList.remove("active");overlay.style.display="none"};
document.getElementById("searchInput").oninput=e=>{
 const q=e.target.value.toLowerCase();
 const list=products.filter(p=>p.name.toLowerCase().includes(q));
 document.getElementById("searchResults").innerHTML=list.length?list.map(p=>`<div class="result"><b>${p.name}</b> — ${money(p.price)}</div>`).join(""):"No products found.";
};
document.getElementById("viewAll").onclick=()=>document.getElementById("products").scrollIntoView({behavior:"smooth"});
const whatsappNumber="923357654140"; document.getElementById("whatsapp").onclick=()=>window.open("https://wa.me/"+whatsappNumber+"?text="+encodeURIComponent("Assalam-o-Alaikum China Mart, mujhe products ke bare mein maloomat chahiye."),"_blank");
